# Instructions

### test_item_detection

- Make sure to open up the relevant image file. The zoom level of the image file should be at 100% for the image
  detection to function correctly.